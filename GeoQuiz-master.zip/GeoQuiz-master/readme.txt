This is the GeoQuiz source code for the Austin Droids Big Nerd Ranch Android Guide training.

Slides for Chapters 1 & 2 can be found at: 

https://docs.google.com/presentation/d/1iWxEbpZNGHVi1ozlVbb86mgUJonnnZaediyHV4pI1j8/edit?usp=sharing

You can also download the completed source from Big Nerd Ranch at the following link:

http://www.bignerdranch.com/solutions/AndroidProgramming2e.zip

Please send any feedback to @AustinDroids 

Thank you!
